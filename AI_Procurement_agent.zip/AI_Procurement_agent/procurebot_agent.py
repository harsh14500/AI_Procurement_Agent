from langchain.llms import Ollama
from langchain.agents import create_pandas_dataframe_agent
import pandas as pd

df = pd.read_csv("cleaned_procuremnet_data.csv")  # replace with actual file path

llm = Ollama(model="llama3")

agent = create_pandas_dataframe_agent(llm, df, verbose=True)

query = "top 5 agencies"
response = agent.invoke(query)
print(response)