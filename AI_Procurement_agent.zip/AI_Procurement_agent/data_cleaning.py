import pandas as pd

df = pd.read_csv("government-procurement-via-gebiz.csv")

df['award_date'] = pd.to_datetime(df['award_date'], errors='coerce', dayfirst=True)
df_cleaned = df.dropna(subset=['tender_description', 'agency', 'award_date'])
df_cleaned = df_cleaned[df_cleaned['awarded_amt'] >= 0]
df_cleaned.columns = [col.strip() for col in df_cleaned.columns]
df_cleaned = df_cleaned.reset_index(drop=True)
df_cleaned.to_csv("cleaned_procurement_data.csv", index=False)

print(df_cleaned.head())