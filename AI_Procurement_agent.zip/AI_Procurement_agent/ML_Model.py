import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

df = pd.read_csv("cleaned_procurement_data.csv")


df['award_date'] = pd.to_datetime(df['award_date'], errors='coerce')
df['award_year'] = df['award_date'].dt.year

df['is_suspicious'] = np.where(
    (df['supplier_name'].str.lower() == 'unknown') | (df['awarded_amt'] == 0), 1, 0
)
df_model = df[['awarded_amt', 'award_year', 'agency', 'tender_description', 'is_suspicious']].dropna()
df_model['agency_enc'] = LabelEncoder().fit_transform(df_model['agency'])
df_model['desc_enc'] = LabelEncoder().fit_transform(df_model['tender_description'])

X = df_model[['awarded_amt', 'award_year', 'agency_enc', 'desc_enc']]
y = df_model['is_suspicious']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

joblib.dump(model, "procurement_rf_model.pkl")

y_pred = model.predict(X_test)
report = classification_report(y_test, y_pred, output_dict=True)
cm = confusion_matrix(y_test, y_pred)

report_df = pd.DataFrame(report).transpose()
report_df.to_csv("classification_report.csv", index=True)

cm_df = pd.DataFrame(cm, index=["Actual Not Suspicious", "Actual Suspicious"],
                        columns=["Predicted Not Suspicious", "Predicted Suspicious"])
cm_df.to_csv("confusion_matrix.csv", index=True)

plt.figure(figsize=(6, 4))
sns.heatmap(cm_df, annot=True, fmt='d', cmap="Blues")
plt.title("Confusion Matrix")
plt.ylabel("Actual Class")
plt.xlabel("Predicted Class")
plt.tight_layout()
plt.savefig("confusion_matrix.png")
plt.show()

print("Model saved as: procurement_rf_model.pkl")
print("Classification Report:\n", report_df)