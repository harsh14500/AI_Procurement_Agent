import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("cleaned_procurement_data.csv")

df['award_date'] = pd.to_datetime(df['award_date'], errors='coerce')

df['award_year'] = df['award_date'].dt.year

sns.set(style="whitegrid")
plt.rcParams["figure.figsize"] = (12, 6)

plt.figure()
sns.countplot(data=df, x='award_year', order=sorted(df['award_year'].dropna().unique()))
plt.title("Total Tenders Awarded Per Year")
plt.xlabel("Year")
plt.ylabel("Number of Tenders")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("total_tenders_per_year.png")  
plt.show()


yearly_spend = df.groupby('award_year')['awarded_amt'].sum().sort_index()
plt.figure()
yearly_spend.plot(kind='bar', color='skyblue')
plt.title("Total Procurement Spend Per Year")
plt.xlabel("Year")
plt.ylabel("Total Amount (SGD)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("total_spend_per_year.png")
plt.show()

top_agencies = df.groupby('agency')['awarded_amt'].sum().sort_values(ascending=False).head(10)
plt.figure()
top_agencies.plot(kind='barh', color='orange')
plt.title("Top 10 Agencies by Spend")
plt.xlabel("Total Amount (SGD)")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.savefig("top_10_agencies.png")  
plt.show()

top_suppliers = df['supplier_name'].value_counts().head(10)
plt.figure()
top_suppliers.plot(kind='bar', color='green')
plt.title("Top 10 Suppliers by Tender Count")
plt.xlabel("Supplier")
plt.ylabel("Number of Tenders Won")
plt.xticks(rotation=75)
plt.tight_layout()
plt.savefig("top_10_suppliers.png") 
plt.show()

suspicious = df[(df['awarded_amt'] == 0) & (df['supplier_name'].str.lower() != 'unknown')]
print("⚠️ Suspicious Tenders (Zero Amount but Supplier Known):")
print(suspicious[['tender_no.', 'supplier_name', 'agency', 'award_date']].head(10))